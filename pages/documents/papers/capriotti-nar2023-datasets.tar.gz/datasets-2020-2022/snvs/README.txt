train_snv_#.tsv Datasets both for the 10-fold cross-validation and training.
test_snv_#.tsv  Testing datasets
The number of Benign and Pathogenic variants are matched downscaling the most 
abundant class and random sampling 

SET      = Cross-validation subset
CHROM    = Chromosome     
POS      = Position of hg38 reference genome    
REF      = Reference allele    
ALT      = Alterantive allele
REGION   = coding/noncoding referred to ucsc knownGene file   
EFFECT   = Pathogenic/Benign
PhD-SNPg = Probability of pathogenicity 
